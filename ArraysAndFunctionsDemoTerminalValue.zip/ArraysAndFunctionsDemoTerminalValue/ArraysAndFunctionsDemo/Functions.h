// Functions.h 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 1 Nov 2021
// Purpose: Function declarations for ArraysAndFunctionsDemo

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <string>

using namespace std;

const int NUMVALUES{ 100 };

void GetNamesFromUser(string names[]);
void DisplayNamesToUser(string names[]);

#endif // !_FUNCTIONS_H
