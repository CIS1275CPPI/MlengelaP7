// Driver.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 1 Nov 2021
// Purpose: 

#include "Functions.h"
using namespace std;

int main()
{
    //Create an array of names
    string names[NUMVALUES];

    //Load array with names from user
    GetNamesFromUser(names);

    //Display array to user
    DisplayNamesToUser(names);

    return 0;
}