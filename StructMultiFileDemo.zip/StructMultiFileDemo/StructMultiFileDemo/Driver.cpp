// .cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 25 Oct 2021
// Purpose: 

#include "Functions.h"
using namespace std;

int main()
{
    //Declare a struct for a book
    Book user_book = GetBookInfoFromUser();

    //Display Book info
    DisplayBookInfo(user_book);

    return 0;
}