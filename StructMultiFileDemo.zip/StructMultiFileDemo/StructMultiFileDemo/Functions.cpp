// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 25 Oct 2021
// Purpose: Functions for StructMultiFileDemo

#include "Functions.h"
using namespace std;

Book GetBookInfoFromUser()
{
    Book book; 

    //Get Book info from user
    cout << "Please enter the following for your book:" << endl;
    cout << "Title: ";
    getline(cin, book.title);
    cout << "Author: ";
    getline(cin, book.author);
    cout << "Subject: ";
    getline(cin, book.subject);
    cout << "Book ID: ";
    cin >> book.book_id;
    cin.ignore();

    return book;
}

void DisplayBookInfo(Book book)
{
    cout << "Title: " << book.title << endl;
    cout << "Author: " << book.author << endl;
    cout << "Subject: " << book.subject << endl;
    cout << "Book ID: " << book.book_id << endl;
}