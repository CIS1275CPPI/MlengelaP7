// Functions.h
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 25 Oct 2021
// Purpose: Functions for StructMultiFileDemo

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <string>
using namespace std;

//Disclaimer No Memory has been harmed or injured by this declaration!
struct Book //<-- User defined type
{
    string title;
    string author;
    string subject;
    int book_id;
};

Book GetBookInfoFromUser();
void DisplayBookInfo(Book book);
#endif // !_FUNCTIONS_H
