// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 1 Nov 2021
// Purpose: Function definitions for ArraysAndFunctionsDemo

#include "Functions.h"
using namespace std;

void GetNamesFromUser(string names[])
{

	string name{""};
	int count = 0;
	do
	{
		cout << "Please enter a name to add (or enter to stop): ";
		getline(cin, name);
		if (name != "")
		{
			names[count] = name;
			count++;
		}
	} while (name != "");
	//How do we get count declared in this scope?
}

void DisplayNamesToUser(string names[])
{
	//Over to this scope so we can use it in the loop?
	for (int i = 0; i < 10; ++i)
	{
		cout<< i+1<<": " << names[i] << endl;
	}
}