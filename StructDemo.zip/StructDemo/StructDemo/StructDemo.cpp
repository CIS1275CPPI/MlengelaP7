// StructDemo.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 25 Oct 2021
// Purpose: Demo how to create a Struct

#include <iostream>
using namespace std;

struct Book
{
    string title;
    string author;
    string subject;
    int book_id;
};

int main()
{
    Book book1;
    Book book2;

    book1.title = "Modern C++ programming";
    book1.subject = "Programming";
    book1.author = "Barbara Johnston";
    book1.book_id = 1234;

    book2.title = "Social Psychology";
    book2.subject = "Psychology";
    book2.author = "Morris Rossenberg";
    book2.book_id = 4321;

    cout << "Book title: " << book1.title << endl;
    cout << "Subject: " << book1.subject << endl;
    cout << "Author: " << book1.author << endl;
    cout << "Book ID: " << book1.book_id << endl;
    cout << endl;

    cout << "Book title: " << book2.title << endl;
    cout << "Subject: " << book2.subject << endl;
    cout << "Author: " << book2.author << endl;
    cout << "Book ID: " << book2.book_id << endl;
    cout << endl;





    return 0;
}