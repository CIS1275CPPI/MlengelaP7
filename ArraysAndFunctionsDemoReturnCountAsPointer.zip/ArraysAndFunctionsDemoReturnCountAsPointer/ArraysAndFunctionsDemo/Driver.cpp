// Driver.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 1 Nov 2021
// Purpose: 

#include "Functions.h"
using namespace std;

int main()
{
    //Create an array of names
    string names[10];
    int count{ 0 };

    //Load array with names from user
    GetNamesFromUser(names, &count);

    //Display array to user
    DisplayNamesToUser(names, count);

    return 0;
}