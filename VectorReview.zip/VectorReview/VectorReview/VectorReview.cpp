// VectorReview.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 25 Oct 2021
// Purpose: Review Vectors

#include <vector>
#include <iostream>
using namespace std;

int main()
{
    vector<string> names;
    names.push_back("Rob");
    names.push_back("Grace");
    names.push_back("Knuth");

    for (int i = 0; i < names.size(); ++i)
    {
        cout << names.at(i) << endl;
    }

    return 0;
}