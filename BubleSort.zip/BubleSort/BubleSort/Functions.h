// Functions.h 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 3 Nov 2021
// Purpose: Functions declarations for Demo Bubble sort

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <random>

using namespace std;

const int NUMVALUES{ 5 };

void CreateRandomNumbersArray(int numbers[], int count);
void DisplayNumbers(const int numbers[], int count);
void SortNumbers(int numbers[], int count);

#endif // !_FUNCTIONS_H

