// Driver.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 3 Nov 2021
// Purpose: Demo Bubble sort

#include "Functions.h"
using namespace std;

int main()
{
    //Seed random number generator
    srand(time(NULL));

    //Create a list of 100 random numbers
    int numbers[NUMVALUES];
    CreateRandomNumbersArray(numbers, NUMVALUES);

    //Display numbers
    DisplayNumbers(numbers, NUMVALUES);

    //Sort numbers
    SortNumbers(numbers, NUMVALUES);

    //Display numbers again
    DisplayNumbers(numbers, NUMVALUES);

    return 0;
}