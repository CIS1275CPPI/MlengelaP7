// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 3 Nov 2021
// Purpose: Functions definitions for Demo Bubble sort


#include "Functions.h"
using namespace std;

void CreateRandomNumbersArray(int numbers[], int count)
{
	for (int i{ 0 }; i < count; ++i)
	{
		numbers[i] = rand() % 100 + 1;
	}
}

void DisplayNumbers(const int numbers[], int count)
{
	for (int i{ 0 }; i < count; ++i)
	{
		cout << numbers[i] << ", ";
	}
	cout << endl << endl;
}

void SortNumbers(int numbers[], int count)
{
	//loop through all the numbers to get val i
	for (int i{ 0 }; i < count-1; ++i)
	{
		//loop through all the numbers comparing to compare i to each other value
		for (int j{ 1 }; j < count; ++j)
		{
			//cout << "numbers[" << j << "]: " << numbers[j];
			//If i > j switch
			if (numbers[j - 1] > numbers[j])
			{
				int temp = numbers[j];
				numbers[j] = numbers[j - 1];
				numbers[j-1] = temp;
			}
		}			
	}
}